All of the pictures are hosted online, so all you need are the files here. In order to view the whole thing, just make sure all the files are in 1 folder together.

Also, i could not, for the life of me, figure out where to add a Marquee. it just didn't fit anywhere. Sorry about that =/